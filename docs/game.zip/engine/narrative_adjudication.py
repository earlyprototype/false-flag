"""
Narrative-Driven Adjudication System
=====================================

Uses hidden metrics to guide LLM character responses whilst
presenting narrative consequences to player.
"""

import logging
import re
from typing import Dict, List, Optional, Tuple, Any
from random import Random

logger = logging.getLogger(__name__)

from models.narrative_state import NarrativeState
from engine.endings import _truncate_decision
from engine.utils import clamp

# Actor Simulation Imports
from models.state_actors import StateActorSystem, ActorResponse
from llm.fanout import generate_group
from llm.model_config import LLMContext
from llm.parse_health import record_fallback, record_miss, record_residue
from llm.parsing import (
    extract_label,
    find_float,
    find_signed_int,
    match_enum,
    strip_decoration,
)
from engine.actor_simulation import (
    simulate_actor_responses,
    calculate_effects_from_responses,
    identify_relevant_actors,
    display_country_name
)


# Mystery-mode leak defence: player-facing calls (this module's quality
# assessment included) never receive the hidden narrative, so their
# output cannot reveal it. The former output scrubber (issue #19) is gone
# with the prompt injection that made it necessary - see
# NarrativeConfig.to_llm_context for the segregation rule.

_SENTENCE_SPLIT = re.compile(r"(?<=[.!?])\s+")


# === EVENT DISPOSITION (issue #25) ===

# Verbs that describe closing a situation out, not merely responding to it.
_CLOSURE_VERBS = (
    "escort", "expel", "remove", "recover", "recovered", "salvage",
    "neutralise", "neutralize", "contain", "restore", "restored",
    "evacuate", "evacuated", "arrest", "detain", "secure", "seal",
    "resolve", "resolved", "conclude", "complete", "shut down", "stand down",
)

_STOPWORDS = frozenset({
    "the", "a", "an", "of", "off", "on", "in", "at", "to", "and", "or",
    "for", "from", "by", "with", "is", "was", "has", "have", "been",
})


def _significant_words(text: str) -> set:
    """Content words, lowercased - used for cheap title/action overlap."""
    return {w for w in re.findall(r"[a-z']+", (text or "").lower())
            if len(w) > 3 and w not in _STOPWORDS}


def _first_sentence(text: str) -> str:
    """The first sentence of ``text``, plain, or '' when there is none."""
    for sentence in _SENTENCE_SPLIT.split((text or "").strip()):
        if sentence.strip():
            return sentence.strip()
    return ""


def _effects_direction(final_effects) -> Dict[str, str]:
    """Applied metric deltas -> {"metric": "up"|"down"|"steady"}."""
    if not final_effects:
        return {}
    return {
        str(metric): ("up" if delta > 0 else "down" if delta < 0 else "steady")
        for metric, delta in final_effects.items()
    }


def _objector_roles(pushback) -> List[str]:
    """Role names out of a pushback list, whatever shape a caller holds it in.

    The engine passes (role, message) tuples; GameManager keeps dicts with a
    "role" key; anything else is stringified. Order preserved, blanks
    dropped.
    """
    roles = []
    for item in pushback or []:
        if isinstance(item, dict):
            role = item.get("role", "")
        elif isinstance(item, (tuple, list)) and item:
            role = item[0]
        else:
            role = item
        role = str(role).strip()
        if role:
            roles.append(role)
    return roles


def record_event_disposition(narrative_state, action: str,
                             quality_assessment: Optional[Dict[str, Any]] = None,
                             final_effects: Optional[Dict[str, int]] = None,
                             pushback=None) -> None:
    """Set how the event under adjudication was left by ``action``.

    Closes the *most recently staged* entry rather than looking one up by
    turn number. ``narrative_state.turn`` is synchronised with the world
    turn only after adjudication, so a turn-keyed lookup finds the previous
    turn's event; and the ledger is append-only with one entry per turn, so
    the last entry is always the one being adjudicated.

    Must be called from every adjudication path - actor-enabled campaigns
    route through ``adjudicate_with_actor_simulation``, so recording in the
    narrative path alone left the ledger permanently open in real play.

    The optional arguments carry the turn's structured consequences into
    the ledger entry (ER-077), whatever disposition it ends up with:

    - ``quality_assessment``: the parsed assessment dict; its reasoning's
      first sentence becomes the entry's one-line ``outcome``.
    - ``final_effects``: the APPLIED metric deltas; recorded as direction
      words ("up"/"down"/"steady"), never numbers.
    - ``pushback``: this turn's advisor pushback; the objecting role names
      are recorded.
    """
    try:
        ledger = getattr(narrative_state, "event_ledger", None)
        if not ledger:
            return
        current = ledger[-1]
        disposition = infer_event_disposition(current.title, action)
        if disposition != "open":
            narrative_state.close_event(
                current.turn, disposition, _truncate_decision(action, 90))
        narrative_state.record_event_consequences(
            current.turn,
            outcome=_first_sentence((quality_assessment or {}).get("reasoning", "")),
            effects_direction=_effects_direction(final_effects),
            objectors=_objector_roles(pushback))
    except Exception:  # pragma: no cover - bookkeeping must never break a turn
        logger.debug("Could not set event disposition", exc_info=True)


def infer_event_disposition(title: str, action: str) -> str:
    """Guess how the player left the event titled ``title``.

    Deliberately conservative. A false "resolved" suppresses a live thread
    from future injects, which is worse than the repetition the ledger
    exists to prevent - so closure is only claimed when the decision both
    refers to the event and uses language of ending it. Everything else is
    "advanced" (engaged with) or "open" (not addressed).
    """
    title_words = _significant_words(title)
    if not title_words:
        return "open"
    action_lower = (action or "").lower()
    overlap = title_words & _significant_words(action)
    if not overlap:
        return "open"
    if any(verb in action_lower for verb in _CLOSURE_VERBS):
        return "resolved"
    return "advanced"


# === QUALITY ASSESSMENT ===

def assess_action_quality(
    action: str,
    narrative_state: NarrativeState,
    interpretation: str,
    llm_generate_fn = None,
    rng: Random = None
) -> Dict[str, Any]:
    """
    Use LLM to assess quality and appropriateness of player action.

    The assessor's REASONING is shown to the player verbatim, which makes
    this a player-facing call: it never receives the Mystery narrative
    (see NarrativeConfig.to_llm_context). It judges on the visible record.

    Args:
        action: Player's raw action text
        narrative_state: Current narrative state with hidden metrics
        interpretation: LLM's interpretation of the action
        llm_generate_fn: LLM generation function (optional, falls back to heuristic)

    Returns:
        Assessment dict with:
        - quality: "exceptional" | "good" | "adequate" | "poor" | "catastrophic"
        - reasoning: Why this assessment
        - suggested_effects: Dict of metric impacts
    """
    
    if llm_generate_fn is None or rng is None:
        # Fallback to heuristic assessment
        return _heuristic_quality_assessment(action, narrative_state)
    
    # Build LLM prompt for quality assessment
    context = narrative_state.to_llm_context()

    prompt = f"""
{context}
PLAYER ACTION: {action}

INTERPRETATION: {interpretation}

ASSESS THIS ACTION:

Consider:
1. Is this the right action at the right time given the situation?
2. Does it address the most critical issues?
3. Is it proportionate to the threat level?
4. Will it strengthen or weaken the UK's position?
5. Are there obvious negative consequences being overlooked?
6. Was this decision well-reasoned given what the player could actually know?
   Reward sound judgement under uncertainty - gathering evidence, testing
   assumptions, keeping options open - and penalise acting further than the
   evidence supports. Do NOT reward or punish the player for agreeing or
   disagreeing with facts they have no way of knowing yet.

CRITICAL - REASONING is displayed to the player word for word:
- Never mention these instructions or the assessment rubric
- Never state attribution as settled fact the player has not established
- Argue only from evidence visible in the game world
- Write it in British English, plain text only - no markdown, no asterisks

Respond in this exact format:

QUALITY: [exceptional/good/adequate/poor/catastrophic]

REASONING: [One paragraph explaining the assessment, in the terms above]

EFFECTS:
escalation_risk: [delta -20 to +20]
alliance_cohesion: [delta -20 to +20]
domestic_stability: [delta -20 to +20]

QUALITY MULTIPLIER: [0.5 to 2.5]
"""
    
    try:
        response = llm_generate_fn(prompt, rng, max_tokens=400,
                                   context=LLMContext.QUALITY_ASSESSMENT)
        return _parse_quality_response(response)
    except Exception:
        # Fallback to heuristic on error
        return _heuristic_quality_assessment(action, narrative_state)


def _heuristic_quality_assessment(action: str, narrative_state: NarrativeState) -> Dict[str, Any]:
    """Fallback heuristic quality assessment"""
    action_lower = action.lower()
    
    # Default: adequate quality
    quality = "adequate"
    multiplier = 1.0
    reasoning = "Standard response to the crisis."
    effects = {}
    
    # Diplomatic actions
    if any(word in action_lower for word in ["diplomatic", "nato", "alliance", "allies", "consult"]):
        effects["alliance_cohesion"] = 5
        quality = "good"
        multiplier = 1.5
        reasoning = "Diplomatic engagement strengthening alliance ties."
    
    # De-escalation
    if any(word in action_lower for word in ["de-escalate", "restraint", "defensive", "caution", "investigate", "evidence"]):
        effects["escalation_risk"] = -5
        quality = "good"
        multiplier = 1.5
        reasoning = "Measured approach showing restraint and good judgment."
    
    # Public messaging
    if any(word in action_lower for word in ["public", "statement", "reassure", "address nation"]):
        effects["domestic_stability"] = 3
    
    # Military deployment
    if any(word in action_lower for word in ["deploy", "surge", "mobilize", "forces"]):
        effects["escalation_risk"] = 5
        if narrative_state.hidden_metrics.escalation_risk > 70:
            quality = "poor"
            multiplier = 0.5
            reasoning = "Escalatory military moves when tensions are already critical."
    
    # Passive response
    if any(word in action_lower for word in ["ignore", "wait", "nothing", "delay"]):
        effects["domestic_stability"] = -5
        effects["alliance_cohesion"] = -3
        quality = "poor"
        multiplier = 0.5
        reasoning = "Passive response when decisive action is needed."
    
    # Catastrophic actions
    if any(word in action_lower for word in ["nuclear", "pre-emptive strike", "attack", "bomb"]):
        effects["escalation_risk"] = 20
        effects["alliance_cohesion"] = -30
        effects["domestic_stability"] = -10
        if narrative_state.hidden_metrics.escalation_risk > 60:
            quality = "catastrophic"
            # Amplify (never invert) the harmful effects: a negative multiplier
            # would flip escalation penalties into rewards in apply_quality_scaling
            multiplier = 2.0
            reasoning = "Aggressive escalation at the worst possible time - risks nuclear war."
    
    # Default baseline if no specific action detected
    if not effects:
        effects = {
            "escalation_risk": 2,
            "domestic_stability": -1
        }
    
    return {
        "quality": quality,
        "multiplier": multiplier,
        "reasoning": reasoning,
        "suggested_effects": effects
    }


def _parse_quality_response(response: str) -> Dict[str, Any]:
    """Parse LLM quality assessment response.

    Args:
        response: Raw LLM text in the QUALITY/REASONING/EFFECTS format.
    """
    lines = response.strip().split("\n")

    quality = None
    reasoning = ""
    effects = {}
    # None marks "not stated" so an explicit 1.0 survives; the quality table
    # below only fills in when the model gave no multiplier at all.
    multiplier = None
    last_field = None
    # A structured label whose value sits on the next line ("QUALITY:\npoor")
    # parks the field here; the next non-empty line resolves it through the
    # same tolerant path the inline value uses.
    pending = None  # ("multiplier",) | ("quality",) | ("metric", name)
    # Non-empty lines the parser neither consumed nor recognised.
    residue = []

    def apply_multiplier(value: str) -> None:
        nonlocal multiplier
        parsed = find_float(value)
        if parsed is not None:
            multiplier = max(0.5, min(2.5, parsed))
        else:
            record_miss("quality_assessment", "multiplier", value)

    def apply_quality(value: str) -> None:
        nonlocal quality
        # match_enum tolerates decoration and annotation: "**Poor**" and
        # "Poor - hasty and escalatory" both resolve to poor.
        verdict = match_enum(
            value, ("exceptional", "good", "adequate", "poor", "catastrophic"))
        if verdict is not None:
            quality = verdict
        else:
            record_miss("quality_assessment", "quality", value)

    def apply_metric(metric: str, value: str) -> None:
        parsed = find_signed_int(value)
        if parsed is not None:
            effects[metric] = parsed
        else:
            record_miss("quality_assessment", metric, value.strip())

    def settle_pending(value: str = "") -> None:
        """Resolve a parked field ("" = the value line never arrived)."""
        nonlocal pending
        if pending is None:
            return
        parked, pending = pending, None
        if parked[0] == "multiplier":
            apply_multiplier(value)
        elif parked[0] == "quality":
            apply_quality(value)
        else:
            apply_metric(parked[1], value)

    def match_metric_line(text):
        """(metric, remainder) when the pre-colon token IS one of the three
        requested metrics (modulo decoration and space/hyphen for
        underscore), else None - a REASONING continuation like
        "escalation: rising" must not move a metric."""
        if ":" not in text:
            return None
        prefix, remainder = text.split(":", 1)
        metric = strip_decoration(prefix).lower().replace(" ", "_").replace("-", "_")
        if metric in ("escalation_risk", "alliance_cohesion", "domestic_stability"):
            return metric, remainder.strip()
        return None

    for line in lines:
        line = line.strip()
        if not line:
            continue

        # QUALITY MULTIPLIER before QUALITY: the shorter label must not
        # shadow the longer one.
        value = extract_label(line, "QUALITY MULTIPLIER")
        if value is not None:
            settle_pending()
            last_field = None
            if value:
                apply_multiplier(value)
            else:
                pending = ("multiplier",)
            continue

        value = extract_label(line, "QUALITY")
        if value is not None:
            settle_pending()
            last_field = None
            if value:
                apply_quality(value)
            else:
                pending = ("quality",)
            continue

        value = extract_label(line, "REASONING")
        if value is not None:
            settle_pending()
            reasoning = value
            last_field = "reasoning"
            continue

        value = extract_label(line, "EFFECTS")
        if value is not None or strip_decoration(line).upper() == "EFFECTS":
            settle_pending()
            last_field = None
            # An inline delta on the header line ("EFFECTS: escalation_risk:
            # -5") is a value, not decoration - feed it through the metric
            # path instead of discarding it with the header.
            if value:
                hit = match_metric_line(value)
                if hit is not None:
                    metric, remainder = hit
                    if remainder:
                        apply_metric(metric, remainder)
                    else:
                        pending = ("metric", metric)
                else:
                    residue.append(value)
            continue

        hit = match_metric_line(line)
        if hit is not None:
            settle_pending()
            last_field = None
            metric, remainder = hit
            if remainder:
                apply_metric(metric, remainder)
            else:
                pending = ("metric", metric)
            continue

        # The line after a bare structured label carries that field's value
        if pending is not None:
            settle_pending(line)
            continue

        # Wrapped continuation of the REASONING paragraph
        if last_field == "reasoning":
            reasoning = f"{reasoning} {line}".strip()
            continue

        residue.append(line)

    settle_pending()
    if residue:
        record_residue("quality_assessment", len(residue), residue[0][:60])

    if quality is None:
        quality = "adequate"
        record_miss("quality_assessment", "quality", "no QUALITY label found")
    if not reasoning:
        record_miss("quality_assessment", "reasoning", "no REASONING label found")
    if not effects:
        record_miss("quality_assessment", "effects", "no metric deltas found")

    # Map quality to multiplier only when the model stated none
    if multiplier is None:
        quality_multipliers = {
            "exceptional": 2.5,
            "good": 1.5,
            "adequate": 1.0,
            "poor": 0.5,
            "catastrophic": 2.0  # amplify the harmful effects; negative would invert them
        }
        multiplier = quality_multipliers.get(quality, 1.0)

    return {
        "quality": quality,
        "multiplier": multiplier,
        "reasoning": reasoning or "Action assessed.",
        "suggested_effects": effects
    }


# === EFFECT DETERMINATION ===

def determine_base_effects(action: str, narrative_state: NarrativeState) -> Dict[str, int]:
    """
    Determine base metric effects using heuristics.
    Similar to current system but returns dict instead of applying directly.
    """
    effects = {}
    action_lower = action.lower()
    
    # Diplomatic actions
    if any(word in action_lower for word in ["diplomatic", "nato", "alliance", "allies", "consult"]):
        effects["alliance_cohesion"] = 5
    
    # Public messaging
    if any(word in action_lower for word in ["public", "statement", "reassure", "address nation"]):
        effects["domestic_stability"] = 3
    
    # Military deployment
    if any(word in action_lower for word in ["deploy", "surge", "mobilize", "forces"]):
        effects["escalation_risk"] = 5
    
    # De-escalation
    if any(word in action_lower for word in ["de-escalate", "restraint", "defensive", "caution"]):
        effects["escalation_risk"] = -5
    
    # Investigation/evidence gathering
    if any(word in action_lower for word in ["investigate", "evidence", "verify", "intelligence"]):
        effects["escalation_risk"] = -3
        effects["alliance_cohesion"] = 3  # Shows responsible approach
    
    # Aggressive actions
    if any(word in action_lower for word in ["nuclear", "strike", "attack", "offensive"]):
        effects["escalation_risk"] = 20
        effects["alliance_cohesion"] = -30
        effects["domestic_stability"] = -10
    
    return effects


def apply_quality_scaling(
    base_effects: Dict[str, int],
    quality_assessment: Dict[str, Any],
    narrative_state: NarrativeState
) -> Dict[str, int]:
    """
    Scale base effects by quality multiplier and add contextual modifiers.
    
    Args:
        base_effects: Base heuristic effects
        quality_assessment: LLM quality assessment with multiplier
        narrative_state: Current state for context
    
    Returns:
        Final scaled effects
    """
    multiplier = quality_assessment["multiplier"]
    suggested = quality_assessment.get("suggested_effects", {})
    
    final_effects = {}
    
    # Scale base effects by quality
    for metric, delta in base_effects.items():
        scaled = int(delta * multiplier)
        # Clamp to reasonable bounds
        scaled = max(-20, min(20, scaled))
        final_effects[metric] = scaled
    
    # Add LLM-suggested effects (if any)
    for metric, delta in suggested.items():
        if metric in final_effects:
            # Average with base effect
            final_effects[metric] = (final_effects[metric] + delta) // 2
        else:
            final_effects[metric] = delta
    
    # Context modifiers based on current state
    m = narrative_state.hidden_metrics
    
    # Diplomatic actions less effective if alliance already strong
    if "alliance_cohesion" in final_effects and final_effects["alliance_cohesion"] > 0:
        if m.alliance_cohesion > 70:
            final_effects["alliance_cohesion"] = final_effects["alliance_cohesion"] // 2
    
    # Public reassurance less effective if crisis severe
    if "domestic_stability" in final_effects and final_effects["domestic_stability"] > 0:
        if m.escalation_risk > 80:
            final_effects["domestic_stability"] = final_effects["domestic_stability"] // 2
    
    return final_effects


# === CHARACTER RESPONSE GENERATION ===

def generate_character_responses(
    action: str,
    quality_assessment: Dict[str, Any],
    final_effects: Dict[str, int],
    narrative_state: NarrativeState,
    llm_generate_fn = None,
    rng: Random = None,
    llm_batch_fn = None
) -> List[Tuple[str, str]]:
    """
    Generate character responses guided by metrics and quality.
    
    Args:
        action: Player action
        quality_assessment: Quality assessment dict
        final_effects: Final metric effects about to be applied
        narrative_state: Current narrative state
        llm_generate_fn: Optional LLM function
    
    Returns:
        List of (character_name, response_text) tuples
    """
    if llm_generate_fn is None or rng is None:
        # Fallback to templated responses
        return _generate_templated_responses(action, quality_assessment, narrative_state)

    # Select key characters to respond
    key_characters = [c for c in _select_responding_characters(narrative_state, final_effects)
                      if c in narrative_state.characters]

    # Each advisor reacts to the same decision and the same assessment; none
    # of them reads another's line. Asked together rather than in sequence.
    chars = [narrative_state.characters[char_id] for char_id in key_characters]
    prompts = [
        build_character_response_prompt(
            character=char,
            action=action,
            quality=quality_assessment["quality"],
            narrative_state=narrative_state,
        )
        for char in chars
    ]
    raw = generate_group(prompts, llm_generate_fn, rng, llm_batch_fn,
                         context=LLMContext.CHARACTER_RESPONSE,
                         max_tokens=CHARACTER_RESPONSE_MAX_TOKENS)

    responses = []
    for char, text in zip(chars, raw):
        cleaned = (text or "").strip().strip('"')
        # The batch path reports a per-prompt failure as "[ERROR: ...]" text
        # rather than raising, and the string is truthy - so without this it
        # survives as the advisor's spoken line and the player watches a
        # cabinet minister read out an HTTP status. The single-call path could
        # not produce this: a failed call raised and the caller substituted
        # the fallback. actor_simulation guards the same marker.
        if cleaned.startswith("[ERROR:"):
            record_fallback("character_response", f"{char.name} error slot")
            cleaned = ""
        elif not cleaned:
            record_fallback("character_response", f"{char.name} empty reply")
        # Same fallback the single-call path used when a response was refused
        responses.append((char.name, cleaned or f"[{char.name}] Understood, Prime Minister."))
    return responses


def _select_responding_characters(
    narrative_state: NarrativeState,
    effects: Dict[str, int]
) -> List[str]:
    """Select which characters should respond based on action effects"""
    responders = []
    
    # Always: NSA provides assessment
    responders.append("uk_nsa")
    
    # If alliance affected: Foreign Secretary
    if "alliance_cohesion" in effects and abs(effects["alliance_cohesion"]) > 5:
        responders.append("uk_foreign_sec")
    
    # If domestic affected: Home Secretary
    if "domestic_stability" in effects and abs(effects["domestic_stability"]) > 5:
        responders.append("uk_home_sec")
    
    # If military action: CDS
    if "escalation_risk" in effects and effects["escalation_risk"] > 5:
        responders.append("uk_cds")
    
    # Limit to 3-4 characters for readability
    return responders[:4]


# Character reactions are two or three sentences - the PROMPT sets the
# length; this cap is only a backstop, sized ~3x the honest answer so it
# never shapes content. Any hit is recorded as a parse-health truncation,
# so a firing backstop is a visible prompt problem, not a silent edit.
# (Thinking models spending their budget on hidden reasoning are handled
# at the driver - OPENAI_COMPAT_REASONING - not by inflating this.)
CHARACTER_RESPONSE_MAX_TOKENS = 300


def build_character_response_prompt(
    character,
    action: str,
    quality: str,
    narrative_state: NarrativeState,
) -> str:
    """Build one advisor's reaction prompt (no call - see generate_group)."""

    context = narrative_state.to_llm_context()

    # Build tone guidance based on quality
    tone_guidance = {
        "exceptional": "impressed and supportive",
        "good": "approving but professional",
        "adequate": "neutral, professional acknowledgment",
        "poor": "concerned and skeptical",
        "catastrophic": "alarmed and strongly opposed"
    }
    tone = tone_guidance.get(quality, "neutral")
    
    prompt = f"""
{context}

PLAYER ACTION: {action}
ACTION QUALITY: {quality}

You are {character.name}.
Your relationship with the PM: {character.relationship.upper()} (trust: {character.trust}/100)
Your current stance: {character.stance_summary}

Respond to the PM's action with a tone that is {tone}.

Keep your response to 2-3 sentences, in character, as if speaking directly to the Prime Minister in a COBRA briefing.
Write in British English, plain text only - no markdown, no asterisks, no bullet markers.

Response:"""

    return prompt


def _generate_templated_responses(
    action: str,
    quality_assessment: Dict[str, Any],
    narrative_state: NarrativeState
) -> List[Tuple[str, str]]:
    """Fallback templated responses"""
    responses = []
    quality = quality_assessment["quality"]
    
    # NSA always responds
    nsa_responses = {
        "exceptional": "Prime Minister, that's an excellent decision. Exactly the right approach.",
        "good": "A sound decision, Prime Minister. This should strengthen our position.",
        "adequate": "Understood, Prime Minister. We'll proceed accordingly.",
        "poor": "Prime Minister, I have concerns about this approach. We may want to reconsider.",
        "catastrophic": "Prime Minister, I must strongly advise against this course of action."
    }
    responses.append(("National Security Advisor", nsa_responses.get(quality, nsa_responses["adequate"])))
    
    return responses


# === SITUATION SUMMARY ===

# The three metrics whose movement the fold reports, in a fixed order so the
# rendered direction words are deterministic.
_EFFECT_LABELS = (
    ("escalation_risk", "escalation risk"),
    ("alliance_cohesion", "alliance cohesion"),
    ("domestic_stability", "domestic stability"),
)


def _effect_directions(final_effects) -> str:
    """Direction words for the applied effects - never the raw numbers.

    The summary is shown to the player in emergent mode and quoted into
    later prompts, so the referee's deltas travel as prose ("escalation
    risk rising"), not as a scoreboard.
    """
    parts = []
    for key, label in _EFFECT_LABELS:
        delta = (final_effects or {}).get(key, 0)
        if delta > 0:
            parts.append(f"{label} rising")
        elif delta < 0:
            parts.append(f"{label} falling")
    return ", ".join(parts) if parts else "no measurable shift in the situation"


def compute_situation_summary(
    narrative_state: NarrativeState,
    action: str,
    llm_generate_fn = None,
    rng: Random = None,
    quality_assessment: Dict[str, Any] = None,
    final_effects: Dict[str, int] = None
) -> Optional[str]:
    """The fold's LLM half: return the new synopsis text, or None.

    Split out of update_situation_summary so the concurrent round in the
    decision pipeline (ER-023) can run the fold alongside the character
    reactions WITHOUT mutating ``narrative_state`` mid-round - the reaction
    prompts render the (old) summary via to_llm_context(), so an in-round
    write would make their content depend on thread scheduling. The caller
    assigns the returned text after the round joins.

    Returns None when no LLM is available or the call fails/returns empty;
    the caller then applies fallback_situation_summary.
    """
    if llm_generate_fn is None or rng is None:
        return None

    previous = (narrative_state.situation_summary or "").strip()

    event_block = ""
    if narrative_state.event_ledger:
        event_block = f"\nTHIS TURN'S EVENT: {narrative_state.event_ledger[-1].title}\n"

    outcome_block = ""
    if quality_assessment:
        quality = quality_assessment.get("quality", "adequate")
        outcome_block = (
            f"\nADJUDICATED OUTCOME: the decision was judged {quality}; "
            f"{_effect_directions(final_effects)}.\n"
        )

    prompt = f"""
PREVIOUS SUMMARY:
{previous or "(none - the campaign has just begun)"}
{event_block}
THE PRIME MINISTER'S DECISION THIS TURN: {action}
{outcome_block}
Summarise the current situation as a running synopsis of the campaign, in
4-6 sentences for the Prime Minister's daily brief. Fold the previous summary
and this turn together: cover what has happened so far, the player's major
decisions, and the current diplomatic posture. Write in plain, serious
prose in British English - no headings, no numbers, no bullet points, no
markdown emphasis of any kind.

Fidelity rules, which outrank brevity: keep every event distinct, with the
place and the attribution the inputs give it - never merge two events or
transfer a culprit, location or casualty count from one to another. If the
inputs do not state who did something, say it is unattributed rather than
inferring. State accusations as accusations, naming who accuses whom of
what.

Compression rules, which outrank completeness: at most SIX sentences, each
ending in a full stop. Events from earlier turns compress to a clause; only
the most recent turn gets a full sentence of detail. Synthesise - do not
recite the event list. Finish the final sentence; never stop mid-thought.

Summary:"""
    try:
        summary = llm_generate_fn(
            prompt, rng, max_tokens=400,
            context=LLMContext.SITUATION_SUMMARY).strip().strip('"')
        if summary:
            return summary
        # An empty reply means the caller substitutes the deterministic
        # fallback synopsis; that substitution must show in parse health.
        record_fallback("situation_summary", "empty reply")
    except Exception:
        logger.debug(
            "LLM situation summary failed; using deterministic fallback",
            exc_info=True,
        )
        record_fallback("situation_summary", "exception")
    return None


def update_situation_summary(
    narrative_state: NarrativeState,
    action: str,
    llm_generate_fn = None,
    rng: Random = None,
    quality_assessment: Dict[str, Any] = None,
    final_effects: Dict[str, int] = None
) -> None:
    """
    Fold this turn into the rolling campaign synopsis (ER-010, ER-017).

    The summary is the primary end-of-turn display in emergent mode and feeds
    to_llm_context() for every downstream prompt, so it must track the story
    rather than stay frozen at its initial value. It is written as a *fold*:
    the previous summary goes back into the prompt alongside this turn's
    event, the player's decision and the adjudicated outcome, so the synopsis
    accumulates the campaign instead of restating the current metrics.

    Args:
        quality_assessment: This turn's quality dict, if adjudication ran.
            Only the quality word is used - never the numbers.
        final_effects: The applied metric deltas, rendered as direction
            words ("escalation risk rising"), not values.
    """
    summary = compute_situation_summary(
        narrative_state, action, llm_generate_fn, rng,
        quality_assessment=quality_assessment, final_effects=final_effects)
    narrative_state.situation_summary = (
        summary if summary else fallback_situation_summary(narrative_state))


def fallback_situation_summary(narrative_state: NarrativeState) -> str:
    """Deterministic fallback synopsis composed from the current hidden state."""
    m = narrative_state.hidden_metrics
    if m.escalation_risk >= 85:
        risk = "The situation stands at the threshold of open war."
    elif m.escalation_risk >= 70:
        risk = "Escalation is severe and the margin for error is narrowing."
    elif m.escalation_risk >= 50:
        risk = "Tensions remain elevated across the North Atlantic."
    else:
        risk = "The immediate crisis appears contained, for now."

    if m.alliance_cohesion >= 70:
        alliance = "NATO stands firmly behind the UK."
    elif m.alliance_cohesion >= 50:
        alliance = "Allied support is holding, though commitments remain cautious."
    elif m.alliance_cohesion >= 30:
        alliance = "Alliance unity is under visible strain."
    else:
        alliance = "The alliance is fracturing and the UK risks standing alone."

    if m.domestic_stability >= 70:
        domestic = "The public mood is steady."
    elif m.domestic_stability >= 50:
        domestic = "The home front is anxious but orderly."
    elif m.domestic_stability >= 30:
        domestic = "Domestic pressure on the Government is mounting."
    else:
        domestic = "Public order is deteriorating."

    parts = [risk, alliance, domestic]
    if narrative_state.active_crises:
        parts.append("Active crises: " + ", ".join(narrative_state.active_crises[-3:]) + ".")
    return " ".join(parts)


def _run_reactions_and_summary_round(
    narrative_state: NarrativeState,
    action: str,
    quality_assessment: Dict[str, Any],
    final_effects: Dict[str, int],
    llm_generate_fn,
    rng: Random,
    llm_batch_fn,
) -> Tuple[List[Tuple[str, str]], Optional[str]]:
    """Round 3 of the decision pipeline: reactions ∥ summary fold (ER-023).

    Returns (character_responses, summary_text_or_None). The summary is
    returned rather than assigned so the caller can order the write after
    its attitude and crisis bookkeeping. Child-seed order: reactions first,
    summary second (see engine/decision_phase.py for the discipline).
    """
    # Lazy import: decision_phase imports this module at its top level.
    from engine.decision_phase import quiet_generate, run_round

    gen = quiet_generate(llm_generate_fn)
    batch = quiet_generate(llm_batch_fn)

    return run_round(
        [("character_responses",
          lambda task_rng: generate_character_responses(
              action, quality_assessment, final_effects, narrative_state,
              gen, task_rng, llm_batch_fn=batch),
          lambda: _generate_templated_responses(
              action, quality_assessment, narrative_state)),
         ("situation_summary",
          lambda task_rng: compute_situation_summary(
              narrative_state, action, gen, task_rng,
              quality_assessment=quality_assessment,
              final_effects=final_effects),
          lambda: None)],
        rng, status="THE ROOM REACTS ── 2 CHANNELS")


# === MAIN ADJUDICATION FUNCTIONS ===

def adjudicate_with_narrative(
    narrative_state: NarrativeState,
    action: str,
    interpretation: str,
    rng: Random,
    llm_generate_fn = None,
    llm_batch_fn = None,
    pushback = None
) -> Tuple[Dict[str, int], List[Tuple[str, str]], str]:
    """
    Complete narrative-driven adjudication pipeline.

    Args:
        narrative_state: Current narrative state (modified in place)
        action: Player action text
        interpretation: LLM interpretation
        rng: Random number generator
        llm_generate_fn: Optional LLM function
        llm_batch_fn: Optional batch generator, forwarded to
            generate_character_responses so the advisor reactions go out
            as one group.
        pushback: Optional advisor pushback raised against this decision
            ((role, message) tuples or dicts); the objecting roles are
            written into the ledger entry's consequences (ER-077).

    Returns:
        (final_effects, character_responses, quality_reasoning)
    """
    
    # 1. Assess action quality and get LLM-suggested effects
    quality_assessment = assess_action_quality(
        action, narrative_state, interpretation, llm_generate_fn, rng
    )
    
    # 2. Scale the LLM's suggested effects by its quality multiplier. The
    # suggestions are the BASE here, so they go in with an empty suggestion
    # dict: passing the same dict as both arguments made apply_quality_scaling
    # merge the unscaled values back in, averaging the multiplier's effect
    # away (a suggested +10 at 0.5 landed as +7, not +5).
    assessment_for_scaling = dict(quality_assessment)
    assessment_for_scaling["suggested_effects"] = {}
    final_effects = apply_quality_scaling(
        quality_assessment["suggested_effects"], assessment_for_scaling, narrative_state
    )
    
    # 3. Apply effects to hidden metrics
    for metric, delta in final_effects.items():
        if hasattr(narrative_state.hidden_metrics, metric):
            current = getattr(narrative_state.hidden_metrics, metric)
            updated = clamp(current + delta)
            setattr(narrative_state.hidden_metrics, metric, updated)
    
    # 3b. Record how this turn's event was left (issue #25), and what it
    # cost: outcome sentence, effect directions, objectors (ER-077).
    record_event_disposition(narrative_state, action,
                             quality_assessment=quality_assessment,
                             final_effects=final_effects,
                             pushback=pushback)

    # 4+7. Character reactions ∥ situation-summary fold: round 3 of the
    # decision pipeline (ER-023). Both read the applied outcome and neither
    # reads the other. The fold's text is assigned only after the round
    # joins (and after the crisis check), so the reaction prompts never
    # race the summary mutation and the deterministic fallback sees the
    # same post-check crisis list it always did.
    character_responses, summary_text = _run_reactions_and_summary_round(
        narrative_state, action, quality_assessment, final_effects,
        llm_generate_fn, rng, llm_batch_fn)

    # 5. Update character attitudes based on action quality
    _update_character_attitudes(narrative_state, quality_assessment["quality"])

    # 6. Check for crisis triggers
    _check_and_trigger_crises(narrative_state)

    # 7. Assign the fold (computed above, alongside the reactions)
    narrative_state.situation_summary = (
        summary_text if summary_text
        else fallback_situation_summary(narrative_state))

    return final_effects, character_responses, quality_assessment["reasoning"]


def adjudicate_with_actor_simulation(
    narrative_state: NarrativeState,
    actor_system: StateActorSystem,
    action: str,
    interpretation: str,
    rng: Random,
    llm_generate_fn,
    world_narrative = None,
    llm_batch_fn = None,
    pushback = None
) -> Tuple[Dict[str, int], List[ActorResponse], List[Tuple[str, str]], str]:
    """
    Enhanced adjudication with multi-agent actor simulation.
    
    Pipeline:
    1. Identify relevant actors
    2. Simulate each actor's response
    3. Calculate effects from responses
    4. Apply to metrics
    5. Update actor relationships
    6. Generate character (advisor) responses
    7. Generate narrative summary

    Args:
        narrative_state: Current narrative state (modified in place)
        actor_system: The state actors available to respond
        action: Player action text
        interpretation: LLM interpretation
        rng: Random number generator
        llm_generate_fn: Function to call the LLM
        world_narrative: Optional NarrativeConfig, handed per-actor to the
            simulation (the roleplay lane). The quality assessment is
            player-facing and never receives it.
        llm_batch_fn: Optional batch generator, forwarded to both
            simulate_actor_responses and generate_character_responses.
        pushback: Optional advisor pushback raised against this decision;
            the objecting roles are written into the ledger entry's
            consequences (ER-077).

    Returns:
        (final_effects, actor_responses, character_responses, reasoning),
        where reasoning is the actor-response summary.
    """
    
    # 1. Identify which actors should respond
    relevant_actor_ids = identify_relevant_actors(action, actor_system, max_actors=3)
    
    # 2. Simulate each actor's response. The Mystery narrative is passed
    # per-actor rather than concatenated into the shared world context, so
    # each capital is played from its OWN authored stance (ER-012). The actor
    # variant of the context omits the UK cabinet's private trust scores -
    # a foreign government must not reason from them (ER-014).
    world_context = narrative_state.to_actor_context()

    actors = [a for a in (actor_system.get_actor(i) for i in relevant_actor_ids) if a]
    actor_responses = simulate_actor_responses(
        actors, action, world_context, llm_generate_fn, rng,
        llm_batch_fn=llm_batch_fn,
        world_narrative=world_narrative
    )
    for actor, response in zip(actors, actor_responses):
        # Update actor's relationship with UK
        actor_system.update_actor_relationship(actor.country_code, response.trust_change)
    
    # 3. Calculate effects from responses
    actor_effects = calculate_effects_from_responses(actor_responses, actor_system)
    
    # 4. Also run quality assessment for player skill
    quality_assessment = assess_action_quality(action, narrative_state, interpretation, llm_generate_fn, rng)

    # Here - unlike adjudicate_with_narrative - the base is the keyword
    # heuristic and the assessment's suggested_effects are a separate second
    # opinion, so apply_quality_scaling's merge of the two is the point of
    # the call rather than a double-count.
    base_effects = determine_base_effects(action, narrative_state)
    quality_effects = apply_quality_scaling(base_effects, quality_assessment, narrative_state)
    
    # 5. Merge actor effects with quality effects (average)
    final_effects = {}
    all_metrics = set(actor_effects.keys()) | set(quality_effects.keys())
    
    for metric in all_metrics:
        actor_val = actor_effects.get(metric, 0)
        quality_val = quality_effects.get(metric, 0)
        # Weight: 60% actor responses, 40% quality assessment
        final_effects[metric] = int(actor_val * 0.6 + quality_val * 0.4)
    
    # 6. Apply to narrative state
    for metric, delta in final_effects.items():
        if hasattr(narrative_state.hidden_metrics, metric):
            current = getattr(narrative_state.hidden_metrics, metric)
            updated = clamp(current + delta)
            setattr(narrative_state.hidden_metrics, metric, updated)

    # 6b. Record how this turn's event was left, and its consequences.
    # Actor-enabled campaigns route here rather than through
    # adjudicate_with_narrative, so this path needs the same bookkeeping or
    # the ledger never closes (issue #25). Recorded AFTER the actor/quality
    # blend so effects_direction reflects the deltas actually applied
    # (ER-077).
    record_event_disposition(narrative_state, action,
                             quality_assessment=quality_assessment,
                             final_effects=final_effects,
                             pushback=pushback)

    # 7+11. Character reactions ∥ situation-summary fold: round 3 of the
    # decision pipeline (ER-023). The fold's text is assigned only after
    # the round joins (and after the crisis check) - see
    # adjudicate_with_narrative for the reasoning.
    character_responses, summary_text = _run_reactions_and_summary_round(
        narrative_state, action, quality_assessment, final_effects,
        llm_generate_fn, rng, llm_batch_fn)

    # 8. Update character attitudes based on action quality. This is the
    # path every live entry point takes whenever the actor file loads, so
    # without this call advisor trust never moved in real play (ER-007).
    _update_character_attitudes(narrative_state, quality_assessment["quality"])

    # 9. Generate narrative summary
    reasoning = _generate_actor_summary(actor_responses, quality_assessment)

    # 10. Check for crisis triggers
    _check_and_trigger_crises(narrative_state)

    # 11. Assign the fold (computed above, alongside the reactions)
    narrative_state.situation_summary = (
        summary_text if summary_text
        else fallback_situation_summary(narrative_state))

    return final_effects, actor_responses, character_responses, reasoning


def _generate_actor_summary(responses: List[ActorResponse], quality: Dict) -> str:
    """Generate human-readable summary of actor responses."""
    summary_parts = []
    
    summary_parts.append(f"Action Quality: {quality['quality'].upper()}")
    summary_parts.append(f"Reasoning: {quality['reasoning']}")
    summary_parts.append("")
    summary_parts.append("International Response:")
    
    for response in responses:
        support_symbol = {
            "yes": "✓",
            "no": "✗",
            "conditional": "○"
        }.get(response.will_support, "?")

        actor_name = display_country_name(response.actor_id)
        # Word-boundary truncation (shared with the debrief recap) so the
        # summary never ends mid-word
        public = _truncate_decision(response.public_response, limit=90)
        summary_parts.append(f"  {support_symbol} {actor_name}: {public}")

    return "\n".join(summary_parts)


def _update_character_attitudes(narrative_state: NarrativeState, quality: str):
    """Update UK advisor trust based on action quality.

    Every ``uk_``-prefixed character moves (dict insertion order, so the
    iteration is deterministic) rather than a hardcoded four-id list that a
    scenario with a different roster would silently miss. The ``usa_nsa``
    character seeded alongside them stays static by design: their commitment
    is moved by diplomacy and the actor simulation, not by how well the PM
    runs the cabinet (ER-007).
    """
    trust_deltas = {
        "exceptional": +5,
        "good": +2,
        "adequate": 0,
        "poor": -3,
        "catastrophic": -8
    }

    delta = trust_deltas.get(quality, 0)

    # Update UK advisors
    for char_id in [cid for cid in narrative_state.characters if cid.startswith("uk_")]:
        narrative_state.update_character_attitude(char_id, trust_delta=delta)


def _check_and_trigger_crises(narrative_state: NarrativeState):
    """Check metrics and trigger narrative crises"""
    m = narrative_state.hidden_metrics
    
    # High escalation risk
    if m.escalation_risk >= 85 and "War Threshold Reached" not in narrative_state.active_crises:
        narrative_state.add_crisis("War Threshold Reached")
        narrative_state.add_event("Crisis: Situation at war threshold")
    
    # Low stability
    if m.domestic_stability < 30 and "Domestic Crisis" not in narrative_state.active_crises:
        narrative_state.add_crisis("Domestic Crisis")
        narrative_state.add_event("Crisis: Public order deteriorating")
    
    # Low cohesion
    if m.alliance_cohesion < 25 and "Alliance Fracturing" not in narrative_state.active_crises:
        narrative_state.add_crisis("Alliance Fracturing")
        narrative_state.add_event("Crisis: NATO unity collapsing")
